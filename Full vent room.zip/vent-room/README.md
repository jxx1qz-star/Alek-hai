# 🌿 The Vent Room — Full Stack

Real auth, email verification, Gmail notifications, owner badge system.

---

## Quick Start

```bash
# 1 — Backend setup
cd backend
cp .env.example .env        # fill in your values (see below)
npm install
node index.js               # starts on :3001

# 2 — Frontend setup (new terminal)
cd frontend
npm install
npx vite                    # starts on :5173
```

Then open **http://localhost:5173**

---

## Owner Account

The owner account is hardcoded in `backend/db.js` (top of the file).

```js
const OWNER_EMAIL    = "amber@theventroom.com";
const OWNER_PASSWORD = "VentRoom@Keeper2024!";
const OWNER_USERNAME = "Amber";
```

**Change these before going live.** The owner account is auto-created when
the backend starts for the first time. It is pre-verified and gets the
"Vent Keeper" badge on all replies.

---

## Gmail Setup (Real Email)

You need a Gmail **App Password** (not your normal Gmail password).

### Steps:
1. Go to your Google Account → **Security**
2. Enable **2-Step Verification** (required)
3. Go to **Security → App Passwords**
4. Select app: **Mail** → Generate
5. Copy the 16-character password

### In your `.env`:
```
GMAIL_USER=your_gmail@gmail.com
GMAIL_APP_PASSWORD=abcd efgh ijkl mnop    # no spaces needed
OWNER_NOTIFY_EMAIL=your_gmail@gmail.com
```

Without Gmail configured, emails are logged to console (dev mode).

---

## Environment Variables (`backend/.env`)

| Variable              | Description                                      |
|-----------------------|--------------------------------------------------|
| `PORT`                | Backend port (default: 3001)                     |
| `JWT_SECRET`          | Long random string — keep secret                 |
| `FRONTEND_URL`        | Your frontend URL (for email links + CORS)       |
| `BACKEND_URL`         | Your backend URL (for email verification links)  |
| `ALLOWED_ORIGINS`     | Comma-separated CORS origins                     |
| `GMAIL_USER`          | Gmail address to send from                       |
| `GMAIL_APP_PASSWORD`  | 16-char Gmail App Password                       |
| `OWNER_NOTIFY_EMAIL`  | Where owner notifications go (default: GMAIL_USER)|

---

## Features

### Auth
- Real email + password sign up
- **Email verification** — link sent to inbox, expires in 24h
- JWT sessions (7-day expiry)
- Bcrypt password hashing (cost 12)
- Rate limiting: 10 auth requests / 15 min
- Timing-safe login (prevents user enumeration)
- Unverified accounts cannot post or reply

### Posts & Replies
- Users can post (Vent / Question / Support)
- Users can reply to any post
- All posts and replies persisted in SQLite

### Owner ("Vent Keeper")
- **"Vent Keeper" badge** shown on owner's name in header + every reply
- Owner can **delete any reply** with a trash button
- Owner does NOT get notified of their own activity
- Owner account auto-seeded at startup

### Gmail Notifications
- Owner receives an email for every new **post**
- Owner receives an email for every new **reply**
- Beautiful HTML emails with link back to the site

---

## File Structure

```
vent-room/
├── backend/
│   ├── index.js            ← Express server
│   ├── db.js               ← SQLite (sql.js) + owner seed
│   ├── mailer.js           ← Nodemailer / Gmail
│   ├── middleware/
│   │   └── auth.js         ← JWT verify + owner check
│   ├── routes/
│   │   ├── auth.js         ← register, verify, login, /me
│   │   └── posts.js        ← CRUD posts + replies + delete
│   ├── .env.example
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── main.jsx
│   │   ├── App.jsx         ← Full UI + auth modal
│   │   └── api.js          ← All API calls
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── start.sh
└── README.md
```

---

## Deployment

For production:
1. Build frontend: `cd frontend && npm run build`
2. Serve `frontend/dist` with nginx or Caddy
3. Run backend with `pm2 start backend/index.js`
4. Set `FRONTEND_URL` and `BACKEND_URL` to your real domain
5. Add `ALLOWED_ORIGINS` = your real frontend domain
6. Use a real `JWT_SECRET` (32+ random chars)
