#!/bin/bash
# ────────────────────────────────────────────────
#  The Vent Room — start both servers
# ────────────────────────────────────────────────
echo ""
echo "🌿 Starting The Vent Room..."
echo ""

# Start backend
cd backend
node index.js &
BACKEND_PID=$!
echo "✅ Backend PID: $BACKEND_PID"

# Start frontend
cd ../frontend
npx vite &
FRONTEND_PID=$!
echo "✅ Frontend PID: $FRONTEND_PID"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Frontend → http://localhost:5173"
echo "  Backend  → http://localhost:3001"
echo "  Health   → http://localhost:3001/api/health"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Press Ctrl+C to stop both servers."

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit" INT TERM
wait
