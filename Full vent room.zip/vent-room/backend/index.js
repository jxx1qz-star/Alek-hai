require("dotenv").config();
const express   = require("express");
const cors      = require("cors");
const rateLimit = require("express-rate-limit");
const { initDb } = require("./db");

const app  = express();
const PORT = process.env.PORT || 3001;

app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  next();
});

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "http://localhost:5173,http://localhost:3000")
  .split(",").map(o => o.trim());

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS blocked: ${origin}`));
  },
  credentials: true,
}));

app.use(express.json({ limit: "16kb" }));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 10,
  standardHeaders: true, legacyHeaders: false,
  message: { error: "Too many attempts. Please wait 15 minutes and try again." },
  skip: (req) => req.path.startsWith("/verify/"),
});

const postLimiter = rateLimit({
  windowMs: 60 * 1000, max: 15,
  message: { error: "You're posting too fast. Please slow down." },
});

// Routes are registered AFTER db is ready (see below)
app.get("/api/health", (req, res) =>
  res.json({ status: "ok", ts: new Date().toISOString() })
);

app.use((req, res) => res.status(404).json({ error: "Not found." }));
app.use((err, req, res, _next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({ error: "Internal server error." });
});

// Init DB first, then mount routes, then listen
initDb().then(() => {
  // Mount routes here so db is ready before any request
  const authRoutes = require("./routes/auth");
  const postRoutes = require("./routes/posts");
  app.use("/api/auth",  authLimiter, authRoutes);
  app.use("/api/posts", postLimiter, postRoutes);

  app.listen(PORT, () => {
    console.log(`\n🌿 Vent Room backend → http://localhost:${PORT}`);
    console.log(`   Health: http://localhost:${PORT}/api/health\n`);
  });
}).catch((err) => {
  console.error("Fatal: DB init failed:", err);
  process.exit(1);
});
