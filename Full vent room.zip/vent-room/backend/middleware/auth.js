const jwt = require("jsonwebtoken");
const { db } = require("../db");

const JWT_SECRET = process.env.JWT_SECRET || "ventroom-dev-secret-CHANGE-IN-PROD";

// Verifies JWT, attaches req.user. Rejects unverified accounts.
function requireAuth(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Authentication required." });
  }

  try {
    const token = auth.slice(7);
    const payload = jwt.verify(token, JWT_SECRET);

    const user = db
      .prepare(
        "SELECT id, email, username, is_verified, is_owner FROM users WHERE id = ?"
      )
      .get(payload.userId);

    if (!user) return res.status(401).json({ error: "Account not found." });
    if (!user.is_verified)
      return res
        .status(403)
        .json({ error: "Please verify your email before posting." });

    req.user = user;
    next();
  } catch (err) {
    if (err.name === "TokenExpiredError") {
      return res.status(401).json({ error: "Session expired. Please sign in again." });
    }
    return res.status(401).json({ error: "Invalid session." });
  }
}

// Must come AFTER requireAuth
function requireOwner(req, res, next) {
  if (!req.user?.is_owner) {
    return res.status(403).json({ error: "Owner access only." });
  }
  next();
}

module.exports = { requireAuth, requireOwner, JWT_SECRET };
