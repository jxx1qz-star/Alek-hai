require("dotenv").config();
const router = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt    = require("jsonwebtoken");
const crypto = require("crypto");
const { get, insert, run } = require("../db");
const { sendVerificationEmail } = require("../mailer");
const { JWT_SECRET } = require("../middleware/auth");

const FRONTEND_URL  = process.env.FRONTEND_URL || "http://localhost:5173";
const TOKEN_TTL_MS  = 24 * 60 * 60 * 1000;

function sanitize(str = "") { return String(str).trim().slice(0, 500); }
function isValidEmail(e)    { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

// ── POST /api/auth/register ────────────────────────────────────────────────
router.post("/register", async (req, res) => {
  try {
    const email    = sanitize(req.body.email || "").toLowerCase();
    const username = sanitize(req.body.username || "");
    const password = sanitize(req.body.password || "");

    if (!email || !username || !password)
      return res.status(400).json({ error: "Email, username and password are required." });
    if (!isValidEmail(email))
      return res.status(400).json({ error: "Please enter a valid email address." });
    if (username.length < 2 || username.length > 30)
      return res.status(400).json({ error: "Username must be 2–30 characters." });
    if (!/^[a-zA-Z0-9_\-. ]+$/.test(username))
      return res.status(400).json({ error: "Username may only contain letters, numbers, spaces, _ - and ." });
    if (password.length < 8)
      return res.status(400).json({ error: "Password must be at least 8 characters." });

    const existing = get("SELECT id, is_verified FROM users WHERE email = ? COLLATE NOCASE", [email]);

    if (existing) {
      if (!existing.is_verified) {
        const token   = crypto.randomBytes(32).toString("hex");
        const expires = Date.now() + TOKEN_TTL_MS;
        run("UPDATE users SET verify_token = ? WHERE id = ?", [`${token}:${expires}`, existing.id]);
        await sendVerificationEmail(email, token);
        return res.json({ message: "Verification email resent — check your inbox (and spam)." });
      }
      return res.status(409).json({ error: "This email is already registered. Try signing in." });
    }

    const hash    = bcrypt.hashSync(password, 12);
    const token   = crypto.randomBytes(32).toString("hex");
    const expires = Date.now() + TOKEN_TTL_MS;

    insert(
      `INSERT INTO users (email, username, password_hash, verify_token) VALUES (?, ?, ?, ?)`,
      [email, username, hash, `${token}:${expires}`]
    );

    await sendVerificationEmail(email, token);
    res.json({ message: "Account created! Check your email for a verification link." });
  } catch (err) {
    console.error("Register error:", err);
    if (err.message?.includes("UNIQUE"))
      return res.status(409).json({ error: "This email is already registered." });
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

// ── GET /api/auth/verify/:token ────────────────────────────────────────────
router.get("/verify/:token", (req, res) => {
  const { token } = req.params;
  const rows = require("../db").all(
    "SELECT id, verify_token FROM users WHERE is_verified = 0 AND verify_token IS NOT NULL"
  );

  const user = rows.find((r) => {
    const [storedToken] = (r.verify_token || "").split(":");
    return storedToken === token;
  });

  if (!user) return res.redirect(`${FRONTEND_URL}?verified=already`);

  const [, expireTs] = (user.verify_token || "").split(":");
  if (expireTs && Date.now() > parseInt(expireTs, 10)) {
    run("UPDATE users SET verify_token = NULL WHERE id = ?", [user.id]);
    return res.redirect(`${FRONTEND_URL}?verified=expired`);
  }

  run("UPDATE users SET is_verified = 1, verify_token = NULL WHERE id = ?", [user.id]);
  res.redirect(`${FRONTEND_URL}?verified=true`);
});

// ── POST /api/auth/login ───────────────────────────────────────────────────
router.post("/login", (req, res) => {
  try {
    const email    = sanitize(req.body.email || "").toLowerCase();
    const password = sanitize(req.body.password || "");

    if (!email || !password)
      return res.status(400).json({ error: "Email and password are required." });

    const user = get("SELECT * FROM users WHERE email = ? COLLATE NOCASE", [email]);

    const dummyHash = "$2a$12$dummyhashforcomparisononlyXXXXXXXXXXXXXXXXXXXXXXXXXX";
    const hash  = user ? user.password_hash : dummyHash;
    const match = bcrypt.compareSync(password, hash);

    if (!user || !match)
      return res.status(401).json({ error: "Invalid email or password." });

    if (!user.is_verified)
      return res.status(403).json({
        error: "Email not verified. Check your inbox.",
        needsVerification: true,
      });

    const token = jwt.sign(
      { userId: user.id, isOwner: !!user.is_owner },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: { id: user.id, email: user.email, username: user.username, isOwner: !!user.is_owner },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Something went wrong." });
  }
});

// ── GET /api/auth/me ───────────────────────────────────────────────────────
router.get("/me", (req, res) => {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer "))
    return res.status(401).json({ error: "No token." });
  try {
    const payload = jwt.verify(auth.slice(7), JWT_SECRET);
    const user    = get("SELECT id, email, username, is_owner FROM users WHERE id = ? AND is_verified = 1", [payload.userId]);
    if (!user) return res.status(401).json({ error: "Not found." });
    res.json({ id: user.id, email: user.email, username: user.username, isOwner: !!user.is_owner });
  } catch {
    res.status(401).json({ error: "Invalid or expired token." });
  }
});

module.exports = router;
