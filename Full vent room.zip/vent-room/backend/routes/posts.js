require("dotenv").config();
const router = require("express").Router();
const { get, all, insert, run } = require("../db");
const { requireAuth, requireOwner } = require("../middleware/auth");
const { notifyOwner } = require("../mailer");

function sanitize(str = "") { return String(str).trim().slice(0, 5000); }

// ── GET /api/posts ─────────────────────────────────────────────────────────
router.get("/", (req, res) => {
  try {
    const posts   = all("SELECT id, username, type, text, created_at FROM posts ORDER BY created_at DESC LIMIT 200");
    const replies = all("SELECT id, post_id, username, is_owner, text, created_at FROM replies ORDER BY created_at ASC");

    const replyMap = {};
    for (const r of replies) {
      if (!replyMap[r.post_id]) replyMap[r.post_id] = [];
      replyMap[r.post_id].push({ ...r, is_owner: !!r.is_owner });
    }

    res.json(posts.map((p) => ({ ...p, replies: replyMap[p.id] || [] })));
  } catch (err) {
    console.error("GET /posts error:", err);
    res.status(500).json({ error: "Could not load posts." });
  }
});

// ── POST /api/posts ────────────────────────────────────────────────────────
router.post("/", requireAuth, async (req, res) => {
  try {
    const type = sanitize(req.body.type || "");
    const text = sanitize(req.body.text || "");

    if (!text)   return res.status(400).json({ error: "Post cannot be empty." });
    if (!["Vent","Question","Support"].includes(type))
      return res.status(400).json({ error: "Invalid post type." });

    const id   = insert(
      "INSERT INTO posts (user_id, username, type, text) VALUES (?, ?, ?, ?)",
      [req.user.id, req.user.username, type, text]
    );
    const post = get("SELECT * FROM posts WHERE id = ?", [id]);

    if (!req.user.is_owner) {
      notifyOwner("post", { username: req.user.username, postType: type, text })
        .catch((e) => console.error("Notify error:", e));
    }

    res.json({ ...post, replies: [] });
  } catch (err) {
    console.error("POST /posts error:", err);
    res.status(500).json({ error: "Could not create post." });
  }
});

// ── POST /api/posts/:id/replies ────────────────────────────────────────────
router.post("/:id/replies", requireAuth, async (req, res) => {
  try {
    const postId = parseInt(req.params.id, 10);
    const text   = sanitize(req.body.text || "");

    if (!text || isNaN(postId))
      return res.status(400).json({ error: "Invalid input." });

    const post = get("SELECT id, text FROM posts WHERE id = ?", [postId]);
    if (!post) return res.status(404).json({ error: "Post not found." });

    const id    = insert(
      "INSERT INTO replies (post_id, user_id, username, is_owner, text) VALUES (?, ?, ?, ?, ?)",
      [postId, req.user.id, req.user.username, req.user.is_owner ? 1 : 0, text]
    );
    const reply = get("SELECT * FROM replies WHERE id = ?", [id]);

    if (!req.user.is_owner) {
      const preview = post.text.length > 70 ? post.text.slice(0, 70) + "…" : post.text;
      notifyOwner("reply", { username: req.user.username, postPreview: preview, replyText: text })
        .catch((e) => console.error("Notify error:", e));
    }

    res.json({ ...reply, is_owner: !!reply.is_owner });
  } catch (err) {
    console.error("POST /replies error:", err);
    res.status(500).json({ error: "Could not add reply." });
  }
});

// ── DELETE /api/posts/replies/:id  (owner only) ────────────────────────────
router.delete("/replies/:id", requireAuth, requireOwner, (req, res) => {
  try {
    const replyId = parseInt(req.params.id, 10);
    if (isNaN(replyId)) return res.status(400).json({ error: "Invalid ID." });

    const reply = get("SELECT id FROM replies WHERE id = ?", [replyId]);
    if (!reply) return res.status(404).json({ error: "Reply not found." });

    run("DELETE FROM replies WHERE id = ?", [replyId]);
    res.json({ deleted: true, id: replyId });
  } catch (err) {
    console.error("DELETE /replies error:", err);
    res.status(500).json({ error: "Could not delete reply." });
  }
});

module.exports = router;
