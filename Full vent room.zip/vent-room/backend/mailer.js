require("dotenv").config();
const nodemailer = require("nodemailer");

const CONFIGURED = !!(process.env.GMAIL_USER && process.env.GMAIL_APP_PASSWORD);

const transporter = CONFIGURED
  ? nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    })
  : null;

if (!CONFIGURED) {
  console.warn(
    "⚠️  Gmail not configured — emails will be logged to console only.\n" +
    "    Set GMAIL_USER and GMAIL_APP_PASSWORD in .env to enable real email."
  );
}

async function sendMail(mailOptions) {
  if (!CONFIGURED) {
    console.log("\n📧 [EMAIL LOG - NOT SENT]");
    console.log("   To     :", mailOptions.to);
    console.log("   Subject:", mailOptions.subject);
    console.log("   Body   :", mailOptions.text || "(HTML email)");
    console.log("");
    return;
  }
  await transporter.sendMail(mailOptions);
}

// ── Verification email sent to new user ──────────────────────────────────────
async function sendVerificationEmail(to, token) {
  const frontendUrl = process.env.FRONTEND_URL || "http://localhost:5173";
  const verifyUrl = `${process.env.BACKEND_URL || "http://localhost:3001"}/api/auth/verify/${token}`;

  await sendMail({
    from: `"The Vent Room" <${process.env.GMAIL_USER || "noreply@theventroom.com"}>`,
    to,
    subject: "🌿 Verify your Vent Room account",
    text: `Click this link to verify your account: ${verifyUrl}`,
    html: `
      <div style="font-family:'DM Sans',sans-serif;max-width:520px;margin:0 auto;background:#111009;color:#f0ebe3;padding:40px;border-radius:20px;border:1px solid rgba(224,148,104,0.2);">
        <h2 style="font-family:'Georgia',serif;color:#e09468;margin:0 0 10px;font-size:24px;letter-spacing:-0.3px;">
          The Vent<span style="color:#e09468;">.</span>Room
        </h2>
        <h3 style="color:#f0ebe3;font-size:18px;margin:0 0 16px;font-weight:600;">Verify your email</h3>
        <p style="color:#9a8d83;line-height:1.7;margin:0 0 24px;font-size:15px;">
          You're almost in. Click the button below to verify your email address and join the community.
        </p>
        <a href="${verifyUrl}"
           style="display:inline-block;padding:14px 28px;background:#e09468;color:#1c0d05;border-radius:100px;text-decoration:none;font-weight:700;font-size:15px;">
          Verify Email
        </a>
        <p style="color:#3a3330;font-size:12px;margin:24px 0 0;line-height:1.6;">
          If you didn't create an account on The Vent Room, just ignore this email.<br/>
          This link expires in 24 hours.
        </p>
      </div>
    `,
  });
}

// ── Owner Gmail notification ──────────────────────────────────────────────────
async function notifyOwner(type, data) {
  const ownerEmail = process.env.OWNER_NOTIFY_EMAIL || process.env.GMAIL_USER;
  if (!ownerEmail) return;

  const frontendUrl = process.env.FRONTEND_URL || "http://localhost:5173";
  let subject, html, text;

  if (type === "post") {
    subject = `📬 New ${data.postType} post on Vent Room`;
    text = `New post from ${data.username}: ${data.text}`;
    html = `
      <div style="font-family:'DM Sans',sans-serif;max-width:520px;margin:0 auto;background:#111009;color:#f0ebe3;padding:36px;border-radius:20px;border:1px solid rgba(224,148,104,0.2);">
        <h2 style="font-family:'Georgia',serif;color:#e09468;margin:0 0 20px;font-size:20px;">
          New ${data.postType} post
        </h2>
        <p style="color:#9a8d83;font-size:13px;margin:0 0 12px;">
          <strong style="color:#f0ebe3;">Posted by:</strong> ${escapeHtml(data.username)}
        </p>
        <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:18px;margin:0 0 20px;">
          <p style="color:#c4bab1;line-height:1.7;margin:0;font-size:15px;">${escapeHtml(data.text)}</p>
        </div>
        <a href="${frontendUrl}#community"
           style="display:inline-block;padding:12px 22px;background:#e09468;color:#1c0d05;border-radius:100px;text-decoration:none;font-weight:700;font-size:14px;">
          View on Vent Room →
        </a>
      </div>
    `;
  } else if (type === "reply") {
    subject = `💬 New reply from ${data.username}`;
    text = `Reply from ${data.username} on "${data.postPreview}": ${data.replyText}`;
    html = `
      <div style="font-family:'DM Sans',sans-serif;max-width:520px;margin:0 auto;background:#111009;color:#f0ebe3;padding:36px;border-radius:20px;border:1px solid rgba(224,148,104,0.2);">
        <h2 style="font-family:'Georgia',serif;color:#e09468;margin:0 0 20px;font-size:20px;">New reply</h2>
        <p style="color:#9a8d83;font-size:13px;margin:0 0 4px;">
          <strong style="color:#f0ebe3;">From:</strong> ${escapeHtml(data.username)}
        </p>
        <p style="color:#5a504a;font-size:12px;margin:0 0 14px;">
          On post: &ldquo;${escapeHtml(data.postPreview)}&rdquo;
        </p>
        <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:18px;margin:0 0 20px;">
          <p style="color:#c4bab1;line-height:1.7;margin:0;font-size:15px;">${escapeHtml(data.replyText)}</p>
        </div>
        <a href="${frontendUrl}#community"
           style="display:inline-block;padding:12px 22px;background:#e09468;color:#1c0d05;border-radius:100px;text-decoration:none;font-weight:700;font-size:14px;">
          View on Vent Room →
        </a>
      </div>
    `;
  }

  await sendMail({
    from: `"The Vent Room" <${process.env.GMAIL_USER || "noreply@theventroom.com"}>`,
    to: ownerEmail,
    subject,
    text,
    html,
  });
}

function escapeHtml(str = "") {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

module.exports = { sendVerificationEmail, notifyOwner };
