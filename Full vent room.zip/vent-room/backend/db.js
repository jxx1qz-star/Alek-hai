require("dotenv").config();
const initSqlJs = require("sql.js");
const bcrypt    = require("bcryptjs");
const fs        = require("fs");
const path      = require("path");

// ╔══════════════════════════════════════════════════════════╗
// ║        OWNER CREDENTIALS  — change these two lines      ║
// ╠══════════════════════════════════════════════════════════╣
const OWNER_EMAIL    = "amber@theventroom.com";   // owner login email
const OWNER_PASSWORD = "VentRoom@Keeper2024!";    // owner login password
const OWNER_USERNAME = "Amber";                   // display name
// ╚══════════════════════════════════════════════════════════╝

const DB_PATH = path.join(__dirname, "ventroom.db");

let db = null;  // sql.js Database instance
let SQL = null; // sql.js module

// Persist to disk every write
function saveDb() {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

// Wrap db.run to auto-save after mutations
function run(sql, params = []) {
  db.run(sql, params);
  saveDb();
}

// Returns array of row objects
function all(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

// Returns single row or null
function get(sql, params = []) {
  const rows = all(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

// Returns lastInsertRowid
function insert(sql, params = []) {
  db.run(sql, params);
  const row = get("SELECT last_insert_rowid() as id");
  saveDb();
  return row ? row.id : null;
}

async function initDb() {
  SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
    console.log("✅ Database loaded from disk →", DB_PATH);
  } else {
    db = new SQL.Database();
    console.log("✅ New database created →", DB_PATH);
  }

  db.run(`PRAGMA foreign_keys = ON`);

  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      email         TEXT    UNIQUE NOT NULL,
      username      TEXT    NOT NULL,
      password_hash TEXT    NOT NULL,
      is_verified   INTEGER DEFAULT 0,
      verify_token  TEXT,
      is_owner      INTEGER DEFAULT 0,
      created_at    TEXT    DEFAULT (datetime('now'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS posts (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id    INTEGER NOT NULL,
      username   TEXT    NOT NULL,
      type       TEXT    NOT NULL,
      text       TEXT    NOT NULL,
      created_at TEXT    DEFAULT (datetime('now'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS replies (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      post_id    INTEGER NOT NULL,
      user_id    INTEGER NOT NULL,
      username   TEXT    NOT NULL,
      is_owner   INTEGER DEFAULT 0,
      text       TEXT    NOT NULL,
      created_at TEXT    DEFAULT (datetime('now'))
    )
  `);

  saveDb();

  // Seed owner if not exists
  const existing = get("SELECT id FROM users WHERE email = ? COLLATE NOCASE", [OWNER_EMAIL]);
  if (!existing) {
    const hash = bcrypt.hashSync(OWNER_PASSWORD, 12);
    insert(
      `INSERT INTO users (email, username, password_hash, is_verified, is_owner) VALUES (?, ?, ?, 1, 1)`,
      [OWNER_EMAIL, OWNER_USERNAME, hash]
    );
    console.log("✅ Owner account created →", OWNER_EMAIL);
  } else {
    console.log("✅ Owner account exists  →", OWNER_EMAIL);
  }
}

module.exports = { initDb, run, all, get, insert, saveDb, OWNER_EMAIL };
