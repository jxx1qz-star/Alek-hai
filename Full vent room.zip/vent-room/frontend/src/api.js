const BASE = "/api";

function getToken() {
  return localStorage.getItem("vr_token");
}

function authHeaders() {
  const t = getToken();
  return t ? { Authorization: `Bearer ${t}` } : {};
}

async function req(method, path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed.");
  return data;
}

export const api = {
  register: (email, username, password) =>
    req("POST", "/auth/register", { email, username, password }),

  login: (email, password) =>
    req("POST", "/auth/login", { email, password }),

  me: () => req("GET", "/auth/me"),

  getPosts: () => req("GET", "/posts"),

  createPost: (type, text) =>
    req("POST", "/posts", { type, text }),

  createReply: (postId, text) =>
    req("POST", `/posts/${postId}/replies`, { text }),

  deleteReply: (replyId) =>
    req("DELETE", `/posts/replies/${replyId}`),
};
