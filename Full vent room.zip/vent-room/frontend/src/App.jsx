import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import {
  Heart, MessageCircle, Shield, Send, Sparkles, UserRound,
  AlertCircle, X, Eye, EyeOff, LogOut, Trash2, CheckCircle,
  Loader2, Mail, Lock, User, ChevronRight, Crown
} from "lucide-react";
import { api } from "./api.js";

// ─── Types ────────────────────────────────────────────────────────────────────
const TYPE_COLORS = { Vent: "#e09468", Question: "#7db5dc", Support: "#82c9a3" };

// ─── Styles ───────────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,700;0,9..144,900;1,9..144,400;1,9..144,700&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --brand: #e09468;
    --brand-hover: #c97b50;
    --bg: #0d0c0b;
    --surface: rgba(255,255,255,0.04);
    --surface-hover: rgba(255,255,255,0.07);
    --border: rgba(255,255,255,0.08);
    --border-brand: rgba(224,148,104,0.25);
    --text: #f0ebe3;
    --text-muted: #9a8d83;
    --text-dim: #5a504a;
    --error: #f4a39a;
    --success: #82c9a3;
  }

  body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; }

  .vr-root { min-height: 100vh; position: relative; overflow-x: hidden; }

  .vr-root::before {
    content: '';
    position: fixed; inset: 0; pointer-events: none; z-index: 0;
    background:
      radial-gradient(ellipse 55% 40% at 10% 8%, rgba(224,148,104,0.09) 0%, transparent 65%),
      radial-gradient(ellipse 40% 55% at 88% 90%, rgba(125,181,220,0.05) 0%, transparent 60%);
  }

  .vr-z { position: relative; z-index: 1; }

  /* ── Header ── */
  .vr-header {
    position: sticky; top: 0; z-index: 50;
    display: flex; align-items: center; justify-content: space-between;
    padding: 15px 32px;
    background: rgba(13,12,11,0.88);
    backdrop-filter: blur(24px);
    border-bottom: 1px solid var(--border-brand);
  }
  .vr-logo { font-family: 'Fraunces', serif; font-weight: 700; font-size: 20px; color: var(--text); letter-spacing: -0.3px; }
  .vr-logo span { color: var(--brand); }
  .vr-nav { display: flex; gap: 24px; align-items: center; }
  .vr-nav-link { color: var(--text-dim); text-decoration: none; font-size: 14px; font-weight: 500; transition: color 0.18s; background: none; border: none; cursor: pointer; }
  .vr-nav-link:hover { color: var(--brand); }

  .vr-user-chip {
    display: flex; align-items: center; gap: 8px;
    background: var(--surface); border: 1px solid var(--border-brand);
    padding: 6px 14px 6px 10px; border-radius: 100px;
    font-size: 13px; font-weight: 600; color: var(--text);
  }
  .vr-owner-crown { color: var(--brand); }

  /* ── Main ── */
  .vr-main { max-width: 1060px; margin: 0 auto; padding: 60px 24px 100px; }

  /* ── Hero ── */
  .vr-hero {
    display: grid; grid-template-columns: 1.25fr 0.75fr;
    gap: 48px; align-items: center; margin-bottom: 64px;
    animation: vrFadeUp 0.65s ease both;
  }
  @media (max-width: 700px) {
    .vr-hero { grid-template-columns: 1fr; gap: 32px; }
    .vr-header { padding: 14px 16px; }
    .vr-main { padding: 36px 16px 80px; }
  }

  .vr-eyebrow {
    display: inline-flex; align-items: center; gap: 7px;
    font-size: 11px; font-weight: 600; letter-spacing: 0.12em;
    text-transform: uppercase; color: var(--brand); margin-bottom: 16px;
  }
  .vr-h1 {
    font-family: 'Fraunces', serif; font-size: clamp(38px, 5.5vw, 66px);
    font-weight: 900; line-height: 1.06; letter-spacing: -1.5px;
    margin-bottom: 20px; color: var(--text);
  }
  .vr-h1 em { font-style: italic; color: var(--brand); }
  .vr-hero-desc { font-size: 16px; line-height: 1.8; color: var(--text-muted); max-width: 440px; margin-bottom: 30px; }
  .vr-btn-row { display: flex; gap: 12px; flex-wrap: wrap; }

  /* ── Buttons ── */
  .vr-btn {
    display: inline-flex; align-items: center; gap: 8px;
    padding: 13px 22px; border-radius: 100px;
    font-size: 14px; font-weight: 600; font-family: 'DM Sans', sans-serif;
    cursor: pointer; text-decoration: none; border: none; transition: all 0.2s;
  }
  .vr-btn:disabled { opacity: 0.55; cursor: not-allowed; transform: none !important; }
  .vr-btn-primary { background: var(--brand); color: #1c0d05; }
  .vr-btn-primary:hover:not(:disabled) { background: var(--brand-hover); transform: translateY(-2px); box-shadow: 0 10px 36px rgba(224,148,104,0.28); }
  .vr-btn-ghost { background: rgba(255,255,255,0.06); color: var(--text); border: 1px solid var(--border); }
  .vr-btn-ghost:hover:not(:disabled) { background: rgba(255,255,255,0.1); }
  .vr-btn-danger { background: rgba(244,100,80,0.12); color: #f4a39a; border: 1px solid rgba(244,100,80,0.2); padding: 6px 12px; border-radius: 8px; font-size: 12px; }
  .vr-btn-danger:hover:not(:disabled) { background: rgba(244,100,80,0.2); }

  /* ── Stat card ── */
  .vr-stat-card {
    background: var(--surface); border: 1px solid var(--border-brand);
    border-radius: 24px; padding: 26px;
    animation: vrFadeUp 0.65s 0.15s ease both;
  }
  .vr-stat-head { display: flex; align-items: center; gap: 14px; margin-bottom: 20px; }
  .vr-icon-box {
    width: 44px; height: 44px; border-radius: 14px; flex-shrink: 0;
    background: rgba(224,148,104,0.12); border: 1px solid rgba(224,148,104,0.22);
    display: flex; align-items: center; justify-content: center; color: var(--brand);
  }
  .vr-stat-title { font-family: 'Fraunces', serif; font-size: 16px; font-weight: 700; margin-bottom: 3px; }
  .vr-stat-sub { font-size: 12.5px; color: var(--text-dim); }
  .vr-stat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px; }
  .vr-stat { background: rgba(0,0,0,0.38); border-radius: 16px; padding: 18px; }
  .vr-stat-num { font-family: 'Fraunces', serif; font-size: 40px; font-weight: 900; color: var(--brand); line-height: 1; margin-bottom: 4px; }
  .vr-stat-label { font-size: 12px; color: var(--text-dim); font-weight: 500; }
  .vr-stat-note { font-size: 12.5px; color: var(--text-dim); line-height: 1.65; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 14px; }

  /* ── Post form ── */
  .vr-post-form {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 24px; padding: 32px; margin-bottom: 48px;
    animation: vrFadeUp 0.65s 0.2s ease both;
  }
  .vr-post-form h2 { font-family: 'Fraunces', serif; font-size: 26px; font-weight: 700; margin-bottom: 6px; letter-spacing: -0.4px; }
  .vr-form-desc { font-size: 14px; color: var(--text-dim); margin-bottom: 20px; }
  .vr-pills { display: flex; gap: 10px; margin-bottom: 18px; flex-wrap: wrap; }
  .vr-pill {
    padding: 8px 18px; border-radius: 100px; font-size: 13px; font-weight: 600;
    cursor: pointer; border: 1px solid transparent; transition: all 0.18s;
    font-family: 'DM Sans', sans-serif; background: none;
  }
  .vr-pill.active { background: var(--brand); color: #1c0d05; border-color: var(--brand); }
  .vr-pill:not(.active) { background: rgba(255,255,255,0.05); color: var(--text-muted); border-color: var(--border); }
  .vr-pill:not(.active):hover { border-color: rgba(224,148,104,0.4); color: var(--brand); }
  .vr-textarea {
    width: 100%; min-height: 118px;
    background: rgba(0,0,0,0.4); border: 1px solid var(--border);
    border-radius: 16px; padding: 18px; color: var(--text);
    font-family: 'DM Sans', sans-serif; font-size: 15px; line-height: 1.7;
    resize: none; outline: none; transition: border-color 0.2s, box-shadow 0.2s;
  }
  .vr-textarea::placeholder { color: #3a3330; }
  .vr-textarea:focus { border-color: rgba(224,148,104,0.4); box-shadow: 0 0 0 4px rgba(224,148,104,0.07); }
  .vr-form-footer { display: flex; justify-content: flex-end; margin-top: 14px; }

  /* ── Gated form banner ── */
  .vr-gated {
    background: rgba(224,148,104,0.06); border: 1px dashed rgba(224,148,104,0.3);
    border-radius: 16px; padding: 20px 24px;
    display: flex; align-items: center; justify-content: space-between; gap: 16px;
    flex-wrap: wrap;
  }
  .vr-gated p { font-size: 14px; color: var(--text-muted); }
  .vr-gated strong { color: var(--text); }

  /* ── Posts ── */
  .vr-section-title { font-family: 'Fraunces', serif; font-size: 28px; font-weight: 900; letter-spacing: -0.5px; margin-bottom: 22px; }
  .vr-post-card {
    background: rgba(255,255,255,0.03); border: 1px solid var(--border);
    border-radius: 24px; overflow: hidden; margin-bottom: 16px;
    transition: border-color 0.2s, box-shadow 0.2s;
    animation: vrFadeUp 0.5s ease both;
  }
  .vr-post-card:hover { border-color: rgba(224,148,104,0.22); box-shadow: 0 4px 32px rgba(0,0,0,0.3); }
  .vr-post-inner { padding: 26px; }
  .vr-post-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
  .vr-post-head-left { display: flex; align-items: center; gap: 12px; }
  .vr-avatar {
    width: 40px; height: 40px; border-radius: 50%;
    background: rgba(224,148,104,0.1); border: 1px solid rgba(224,148,104,0.18);
    display: flex; align-items: center; justify-content: center; color: var(--brand); flex-shrink: 0;
  }
  .vr-post-name { font-weight: 600; font-size: 14px; }
  .vr-post-type { font-size: 11px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; margin-top: 2px; }
  .vr-post-text { font-size: 15.5px; line-height: 1.78; color: #c4bab1; margin-bottom: 20px; }

  /* ── Replies ── */
  .vr-reply { border-radius: 14px; padding: 14px 16px; margin-bottom: 10px; }
  .vr-reply.owner-reply { background: rgba(224,148,104,0.09); border: 1px solid rgba(224,148,104,0.25); }
  .vr-reply.member-reply { background: rgba(0,0,0,0.28); border: 1px solid var(--border); }
  .vr-reply-header { display: flex; align-items: center; gap: 8px; margin-bottom: 7px; justify-content: space-between; }
  .vr-reply-header-left { display: flex; align-items: center; gap: 8px; }
  .vr-reply-name { font-size: 13px; font-weight: 700; }
  .vr-owner-badge {
    font-size: 9.5px; background: var(--brand); color: #1c0d05;
    padding: 2px 8px; border-radius: 100px; font-weight: 800;
    letter-spacing: 0.09em; text-transform: uppercase;
    display: inline-flex; align-items: center; gap: 4px;
  }
  .vr-reply-text { font-size: 13.5px; color: var(--text-muted); line-height: 1.65; }

  /* ── Reply form ── */
  .vr-reply-form { background: rgba(0,0,0,0.28); border-radius: 16px; padding: 14px 16px; margin-top: 14px; }
  .vr-reply-row { display: flex; gap: 10px; }
  .vr-reply-input {
    flex: 1; background: rgba(255,255,255,0.05); border: 1px solid var(--border);
    border-radius: 12px; padding: 11px 15px; color: var(--text);
    font-family: 'DM Sans', sans-serif; font-size: 14px; outline: none; transition: border-color 0.2s;
  }
  .vr-reply-input::placeholder { color: #3a3330; }
  .vr-reply-input:focus { border-color: rgba(224,148,104,0.4); }
  .vr-reply-btn {
    background: var(--brand); color: #1c0d05; border: none;
    padding: 11px 18px; border-radius: 12px; font-size: 13.5px; font-weight: 600;
    cursor: pointer; font-family: 'DM Sans', sans-serif;
    transition: all 0.18s; display: flex; align-items: center; gap: 6px; flex-shrink: 0;
  }
  .vr-reply-btn:hover:not(:disabled) { background: var(--brand-hover); transform: translateY(-1px); }
  .vr-reply-btn:disabled { opacity: 0.5; cursor: not-allowed; }

  /* ── Sign-in required banner (inside post card) ── */
  .vr-login-nudge {
    font-size: 13px; color: var(--text-dim); padding: 12px 0 0;
    border-top: 1px solid var(--border); margin-top: 14px;
    display: flex; align-items: center; gap: 10px;
  }
  .vr-login-nudge button {
    color: var(--brand); font-weight: 600; background: none; border: none; cursor: pointer; font-size: 13px;
    text-decoration: underline; text-underline-offset: 3px;
  }

  /* ── Safety ── */
  .vr-safety {
    margin-top: 52px;
    background: rgba(255,90,80,0.05); border: 1px solid rgba(255,90,80,0.12);
    border-radius: 20px; padding: 28px;
    animation: vrFadeUp 0.65s 0.3s ease both;
  }
  .vr-safety-title {
    font-family: 'Fraunces', serif; font-size: 17px; font-weight: 700;
    color: var(--error); margin-bottom: 10px;
    display: flex; align-items: center; gap: 8px;
  }
  .vr-safety p { font-size: 13.5px; color: var(--text-dim); line-height: 1.75; }

  /* ── Auth Modal ── */
  .vr-overlay {
    position: fixed; inset: 0; z-index: 200;
    background: rgba(0,0,0,0.75); backdrop-filter: blur(12px);
    display: flex; align-items: center; justify-content: center; padding: 24px;
    animation: vrFadeIn 0.18s ease;
  }
  .vr-modal {
    background: #141210; border: 1px solid var(--border-brand);
    border-radius: 28px; padding: 40px; width: 100%; max-width: 440px;
    position: relative; animation: vrSlideUp 0.25s ease;
    box-shadow: 0 32px 80px rgba(0,0,0,0.6);
  }
  .vr-modal-close {
    position: absolute; top: 18px; right: 18px;
    background: var(--surface); border: 1px solid var(--border); border-radius: 50%;
    width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;
    cursor: pointer; color: var(--text-muted); transition: all 0.18s;
  }
  .vr-modal-close:hover { background: var(--surface-hover); color: var(--text); }
  .vr-modal h2 { font-family: 'Fraunces', serif; font-size: 28px; font-weight: 900; letter-spacing: -0.5px; margin-bottom: 6px; }
  .vr-modal-sub { font-size: 14px; color: var(--text-muted); margin-bottom: 28px; line-height: 1.6; }

  /* ── Form Fields ── */
  .vr-field { margin-bottom: 16px; }
  .vr-label { font-size: 12.5px; font-weight: 600; color: var(--text-muted); display: block; margin-bottom: 7px; text-transform: uppercase; letter-spacing: 0.06em; }
  .vr-input-wrap { position: relative; }
  .vr-input-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--text-dim); pointer-events: none; }
  .vr-input {
    width: 100%;
    background: rgba(0,0,0,0.45); border: 1px solid var(--border);
    border-radius: 14px; padding: 13px 16px 13px 42px; color: var(--text);
    font-family: 'DM Sans', sans-serif; font-size: 15px; outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  .vr-input::placeholder { color: #3a3330; }
  .vr-input:focus { border-color: rgba(224,148,104,0.5); box-shadow: 0 0 0 4px rgba(224,148,104,0.08); }
  .vr-input.error { border-color: rgba(244,100,80,0.5); }
  .vr-pw-toggle {
    position: absolute; right: 14px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer; color: var(--text-dim);
    display: flex; align-items: center; transition: color 0.18s;
  }
  .vr-pw-toggle:hover { color: var(--text-muted); }

  /* ── Alert boxes ── */
  .vr-alert {
    border-radius: 12px; padding: 12px 16px; margin-bottom: 18px;
    font-size: 13.5px; line-height: 1.55; display: flex; gap: 10px; align-items: flex-start;
  }
  .vr-alert.error   { background: rgba(244,100,80,0.1); border: 1px solid rgba(244,100,80,0.2); color: var(--error); }
  .vr-alert.success { background: rgba(130,201,163,0.1); border: 1px solid rgba(130,201,163,0.2); color: var(--success); }

  /* ── Verification banner ── */
  .vr-verify-banner {
    background: rgba(130,201,163,0.1); border: 1px solid rgba(130,201,163,0.3);
    border-radius: 20px; padding: 24px; margin-bottom: 32px; text-align: center;
    animation: vrFadeUp 0.5s ease;
  }
  .vr-verify-banner h3 { font-family: 'Fraunces', serif; font-size: 20px; margin-bottom: 8px; color: var(--success); }
  .vr-verify-banner p  { font-size: 14px; color: var(--text-muted); line-height: 1.6; }

  /* ── Spinner ── */
  .spin { animation: vrSpin 0.8s linear infinite; }

  /* ── Tabs ── */
  .vr-tabs { display: flex; gap: 4px; background: rgba(0,0,0,0.3); border-radius: 14px; padding: 4px; margin-bottom: 24px; }
  .vr-tab {
    flex: 1; padding: 9px 16px; border-radius: 10px; font-size: 14px; font-weight: 600;
    border: none; cursor: pointer; transition: all 0.18s; font-family: 'DM Sans', sans-serif;
  }
  .vr-tab.active { background: var(--brand); color: #1c0d05; }
  .vr-tab:not(.active) { background: none; color: var(--text-dim); }
  .vr-tab:not(.active):hover { color: var(--text); }

  /* ── Empty state ── */
  .vr-empty { text-align: center; padding: 48px 24px; color: var(--text-dim); }
  .vr-empty h3 { font-family: 'Fraunces', serif; font-size: 20px; color: var(--text-muted); margin-bottom: 8px; }
  .vr-empty p  { font-size: 14px; }

  /* ── Animations ── */
  @keyframes vrFadeUp   { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes vrFadeIn   { from { opacity: 0; } to { opacity: 1; } }
  @keyframes vrSlideUp  { from { opacity: 0; transform: translateY(24px) scale(0.97); } to { opacity: 1; transform: translateY(0) scale(1); } }
  @keyframes vrSpin     { to { transform: rotate(360deg); } }

  .vr-divider { display: flex; align-items: center; gap: 12px; margin: 20px 0; }
  .vr-divider span { font-size: 12px; color: var(--text-dim); white-space: nowrap; }
  .vr-divider::before, .vr-divider::after { content: ''; flex: 1; height: 1px; background: var(--border); }
`;

// ─── Auth Modal ───────────────────────────────────────────────────────────────
function AuthModal({ onClose, onSuccess, defaultTab = "login", verifiedMsg }) {
  const [tab, setTab]           = useState(defaultTab);
  const [email, setEmail]       = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw]     = useState(false);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [success, setSuccess]   = useState(verifiedMsg || "");

  const submit = async () => {
    setError(""); setSuccess(""); setLoading(true);
    try {
      if (tab === "login") {
        const data = await api.login(email, password);
        localStorage.setItem("vr_token", data.token);
        onSuccess(data.user);
      } else {
        const data = await api.register(email, username, password);
        setSuccess(data.message);
        setEmail(""); setUsername(""); setPassword("");
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const onKey = (e) => e.key === "Enter" && submit();

  return (
    <div className="vr-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="vr-modal">
        <button className="vr-modal-close" onClick={onClose}><X size={14} /></button>

        <div className="vr-tabs">
          <button className={`vr-tab${tab === "login" ? " active" : ""}`} onClick={() => { setTab("login"); setError(""); setSuccess(""); }}>Sign in</button>
          <button className={`vr-tab${tab === "register" ? " active" : ""}`} onClick={() => { setTab("register"); setError(""); setSuccess(""); }}>Create account</button>
        </div>

        <h2>{tab === "login" ? "Welcome back" : "Join the community"}</h2>
        <p className="vr-modal-sub">
          {tab === "login"
            ? "Sign in to post and support others."
            : "Create an account to share and connect."}
        </p>

        {error   && <div className="vr-alert error"><AlertCircle size={15}/> {error}</div>}
        {success && <div className="vr-alert success"><CheckCircle size={15}/> {success}</div>}

        {tab === "register" && (
          <div className="vr-field">
            <label className="vr-label">Username</label>
            <div className="vr-input-wrap">
              <User size={15} className="vr-input-icon"/>
              <input className={`vr-input${error ? " error" : ""}`} placeholder="Your display name" value={username}
                onChange={e => setUsername(e.target.value)} onKeyDown={onKey} />
            </div>
          </div>
        )}

        <div className="vr-field">
          <label className="vr-label">Email</label>
          <div className="vr-input-wrap">
            <Mail size={15} className="vr-input-icon"/>
            <input className={`vr-input${error ? " error" : ""}`} type="email" placeholder="you@email.com"
              value={email} onChange={e => setEmail(e.target.value)} onKeyDown={onKey} />
          </div>
        </div>

        <div className="vr-field" style={{ marginBottom: 24 }}>
          <label className="vr-label">Password</label>
          <div className="vr-input-wrap">
            <Lock size={15} className="vr-input-icon"/>
            <input className={`vr-input${error ? " error" : ""}`} type={showPw ? "text" : "password"}
              placeholder={tab === "register" ? "Min. 8 characters" : "Your password"}
              value={password} onChange={e => setPassword(e.target.value)} onKeyDown={onKey} />
            <button className="vr-pw-toggle" type="button" onClick={() => setShowPw(p => !p)}>
              {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
            </button>
          </div>
        </div>

        <button className="vr-btn vr-btn-primary" style={{ width: "100%", justifyContent: "center" }}
          onClick={submit} disabled={loading}>
          {loading ? <Loader2 size={15} className="spin"/> : <ChevronRight size={15}/>}
          {loading ? "Please wait…" : tab === "login" ? "Sign in" : "Create account"}
        </button>

        {tab === "login" && (
          <>
            <div className="vr-divider"><span>or</span></div>
            <button className="vr-btn vr-btn-ghost" style={{ width: "100%", justifyContent: "center" }}
              onClick={() => { setTab("register"); setError(""); setSuccess(""); }}>
              Create a new account
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser]         = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authTab, setAuthTab]   = useState("login");
  const [verifiedMsg, setVerifiedMsg] = useState("");

  const [posts, setPosts]       = useState([]);
  const [postsLoading, setPostsLoading] = useState(true);
  const [newPost, setNewPost]   = useState("");
  const [postType, setPostType] = useState("Vent");
  const [postLoading, setPostLoading] = useState(false);
  const [postError, setPostError]     = useState("");

  const [replyText, setReplyText]       = useState({});
  const [replyLoading, setReplyLoading] = useState({});
  const [replyError, setReplyError]     = useState({});
  const [deletingId, setDeletingId]     = useState(null);

  const totalReplies = useMemo(() => posts.reduce((s, p) => s + p.replies.length, 0), [posts]);

  // ── Check for email verification redirect ────────────────────────────────
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verified = params.get("verified");
    if (verified === "true") {
      setVerifiedMsg("✅ Email verified! You can now sign in.");
      setShowAuth(true); setAuthTab("login");
    } else if (verified === "expired") {
      setVerifiedMsg("⚠️ Verification link expired. Please register again.");
      setShowAuth(true); setAuthTab("register");
    } else if (verified === "already") {
      setVerifiedMsg("✅ Already verified — just sign in!");
      setShowAuth(true); setAuthTab("login");
    }
    window.history.replaceState({}, "", window.location.pathname);
  }, []);

  // ── Restore session ──────────────────────────────────────────────────────
  useEffect(() => {
    const token = localStorage.getItem("vr_token");
    if (!token) { setAuthChecked(true); return; }
    api.me().then(setUser).catch(() => localStorage.removeItem("vr_token")).finally(() => setAuthChecked(true));
  }, []);

  // ── Load posts ───────────────────────────────────────────────────────────
  const loadPosts = useCallback(() => {
    setPostsLoading(true);
    api.getPosts().then(setPosts).catch(console.error).finally(() => setPostsLoading(false));
  }, []);

  useEffect(() => { loadPosts(); }, [loadPosts]);

  // ── Add post ─────────────────────────────────────────────────────────────
  const addPost = async () => {
    if (!newPost.trim()) return;
    setPostLoading(true); setPostError("");
    try {
      const post = await api.createPost(postType, newPost.trim());
      setPosts(prev => [post, ...prev]);
      setNewPost("");
    } catch (e) {
      setPostError(e.message);
    } finally {
      setPostLoading(false);
    }
  };

  // ── Add reply ────────────────────────────────────────────────────────────
  const addReply = async (postId) => {
    const text = (replyText[postId] || "").trim();
    if (!text) return;
    setReplyLoading(r => ({ ...r, [postId]: true }));
    setReplyError(r => ({ ...r, [postId]: "" }));
    try {
      const reply = await api.createReply(postId, text);
      setPosts(prev => prev.map(p =>
        p.id !== postId ? p : { ...p, replies: [...p.replies, reply] }
      ));
      setReplyText(r => ({ ...r, [postId]: "" }));
    } catch (e) {
      setReplyError(r => ({ ...r, [postId]: e.message }));
    } finally {
      setReplyLoading(r => ({ ...r, [postId]: false }));
    }
  };

  // ── Delete reply (owner only) ────────────────────────────────────────────
  const deleteReply = async (postId, replyId) => {
    if (!window.confirm("Delete this reply?")) return;
    setDeletingId(replyId);
    try {
      await api.deleteReply(replyId);
      setPosts(prev => prev.map(p =>
        p.id !== postId ? p : { ...p, replies: p.replies.filter(r => r.id !== replyId) }
      ));
    } catch (e) {
      alert(e.message);
    } finally {
      setDeletingId(null);
    }
  };

  const logout = () => {
    localStorage.removeItem("vr_token");
    setUser(null);
  };

  const openAuth = (tab = "login") => { setAuthTab(tab); setShowAuth(true); };

  if (!authChecked) {
    return (
      <>
        <style>{css}</style>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh", background: "#0d0c0b" }}>
          <Loader2 size={28} color="#e09468" className="spin"/>
        </div>
      </>
    );
  }

  return (
    <>
      <style>{css}</style>
      <div className="vr-root">
        <div className="vr-z">

          {/* ── Header ─────────────────────────────────────────────────── */}
          <header className="vr-header">
            <div className="vr-logo">The Vent<span>.</span>Room</div>
            <nav className="vr-nav">
              <a href="#post" className="vr-nav-link">Post</a>
              <a href="#community" className="vr-nav-link">Community</a>
              <a href="#safety" className="vr-nav-link">Safety</a>

              {user ? (
                <>
                  <div className="vr-user-chip">
                    {user.isOwner
                      ? <Crown size={13} className="vr-owner-crown"/>
                      : <UserRound size={13} style={{ color: "#9a8d83" }}/>}
                    {user.username}
                    {user.isOwner && (
                      <span className="vr-owner-badge" style={{ marginLeft: 4 }}>
                        <Crown size={8}/> Vent Keeper
                      </span>
                    )}
                  </div>
                  <button className="vr-nav-link" onClick={logout} title="Sign out">
                    <LogOut size={15}/>
                  </button>
                </>
              ) : (
                <>
                  <button className="vr-nav-link" onClick={() => openAuth("login")}>Sign in</button>
                  <button className="vr-btn vr-btn-primary" style={{ padding: "9px 18px", fontSize: 13 }}
                    onClick={() => openAuth("register")}>
                    Join
                  </button>
                </>
              )}
            </nav>
          </header>

          <main className="vr-main">

            {/* ── Verified banner ──────────────────────────────────────── */}
            {verifiedMsg && !showAuth && (
              <div className="vr-verify-banner">
                <CheckCircle size={32} color="#82c9a3" style={{ marginBottom: 8 }}/>
                <h3>You're verified!</h3>
                <p>{verifiedMsg}</p>
              </div>
            )}

            {/* ── Hero ─────────────────────────────────────────────────── */}
            <section className="vr-hero" id="hero">
              <div>
                <div className="vr-eyebrow"><Sparkles size={13}/> safe space community</div>
                <h1 className="vr-h1">A place to ask, <em>vent,</em> and be heard.</h1>
                <p className="vr-hero-desc">
                  Share what's heavy, ask questions, and let others respond with care.
                  Our community is here to listen, not judge.
                </p>
                <div className="vr-btn-row">
                  {user
                    ? <a href="#post" className="vr-btn vr-btn-primary"><Heart size={15}/> Start Venting</a>
                    : <button className="vr-btn vr-btn-primary" onClick={() => openAuth("register")}>
                        <Heart size={15}/> Join the Community
                      </button>
                  }
                  <a href="#community" className="vr-btn vr-btn-ghost">Read Posts</a>
                </div>
              </div>

              <div className="vr-stat-card">
                <div className="vr-stat-head">
                  <div className="vr-icon-box"><Shield size={20}/></div>
                  <div>
                    <div className="vr-stat-title">Community stats</div>
                    <div className="vr-stat-sub">Support grows when people speak.</div>
                  </div>
                </div>
                <div className="vr-stat-grid">
                  <div className="vr-stat">
                    <div className="vr-stat-num">{posts.length}</div>
                    <div className="vr-stat-label">posts</div>
                  </div>
                  <div className="vr-stat">
                    <div className="vr-stat-num">{totalReplies}</div>
                    <div className="vr-stat-label">replies</div>
                  </div>
                </div>
                <p className="vr-stat-note">Peer support only — not emergency care or professional medical advice.</p>
              </div>
            </section>

            {/* ── Post Form ────────────────────────────────────────────── */}
            <section id="post" className="vr-post-form">
              <h2>Share something</h2>
              <p className="vr-form-desc">Ask a question, vent, or just put your thoughts somewhere safe.</p>

              {user ? (
                <>
                  <div className="vr-pills">
                    {["Vent","Question","Support"].map(t => (
                      <button key={t} className={`vr-pill${postType === t ? " active" : ""}`}
                        onClick={() => setPostType(t)}>{t}</button>
                    ))}
                  </div>
                  <textarea className="vr-textarea" value={newPost}
                    onChange={e => setNewPost(e.target.value)}
                    placeholder="Type what you need to get out…"/>
                  {postError && <div className="vr-alert error" style={{ marginTop: 10 }}><AlertCircle size={14}/> {postError}</div>}
                  <div className="vr-form-footer">
                    <button className="vr-btn vr-btn-primary" onClick={addPost} disabled={postLoading || !newPost.trim()}>
                      {postLoading ? <Loader2 size={14} className="spin"/> : <Send size={14}/>}
                      {postLoading ? "Posting…" : "Post"}
                    </button>
                  </div>
                </>
              ) : (
                <div className="vr-gated">
                  <p><strong>Want to post?</strong> Create a free account to share with the community.</p>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button className="vr-btn vr-btn-primary" style={{ padding: "10px 18px", fontSize: 13 }}
                      onClick={() => openAuth("register")}>Sign up free</button>
                    <button className="vr-btn vr-btn-ghost" style={{ padding: "10px 18px", fontSize: 13 }}
                      onClick={() => openAuth("login")}>Sign in</button>
                  </div>
                </div>
              )}
            </section>

            {/* ── Community Posts ──────────────────────────────────────── */}
            <section id="community">
              <div className="vr-section-title">Community posts</div>

              {postsLoading ? (
                <div style={{ display: "flex", justifyContent: "center", padding: 48 }}>
                  <Loader2 size={28} color="#e09468" className="spin"/>
                </div>
              ) : posts.length === 0 ? (
                <div className="vr-empty">
                  <h3>No posts yet</h3>
                  <p>Be the first to share something with the community.</p>
                </div>
              ) : (
                posts.map((post, i) => (
                  <div key={post.id} className="vr-post-card" style={{ animationDelay: `${i * 0.06}s` }}>
                    <div className="vr-post-inner">
                      <div className="vr-post-head">
                        <div className="vr-post-head-left">
                          <div className="vr-avatar"><UserRound size={17}/></div>
                          <div>
                            <div className="vr-post-name">{post.username}</div>
                            <div className="vr-post-type" style={{ color: TYPE_COLORS[post.type] || "#e09468" }}>
                              {post.type}
                            </div>
                          </div>
                        </div>
                        <MessageCircle size={17} style={{ color: "#2e2a27" }}/>
                      </div>

                      <p className="vr-post-text">{post.text}</p>

                      {/* Replies */}
                      <div>
                        {post.replies.map((reply) => (
                          <div key={reply.id} className={`vr-reply ${reply.is_owner ? "owner-reply" : "member-reply"}`}>
                            <div className="vr-reply-header">
                              <div className="vr-reply-header-left">
                                <span className="vr-reply-name">{reply.username}</span>
                                {reply.is_owner && (
                                  <span className="vr-owner-badge">
                                    <Crown size={8}/> Vent Keeper
                                  </span>
                                )}
                              </div>
                              {/* Owner delete button */}
                              {user?.isOwner && (
                                <button className="vr-btn vr-btn-danger"
                                  disabled={deletingId === reply.id}
                                  onClick={() => deleteReply(post.id, reply.id)}
                                  title="Delete reply">
                                  {deletingId === reply.id
                                    ? <Loader2 size={11} className="spin"/>
                                    : <Trash2 size={11}/>}
                                  Delete
                                </button>
                              )}
                            </div>
                            <p className="vr-reply-text">{reply.text}</p>
                          </div>
                        ))}
                      </div>

                      {/* Reply form — only for logged-in users */}
                      {user ? (
                        <div className="vr-reply-form">
                          {replyError[post.id] && (
                            <div className="vr-alert error" style={{ marginBottom: 10 }}>
                              <AlertCircle size={13}/> {replyError[post.id]}
                            </div>
                          )}
                          <div className="vr-reply-row">
                            <input className="vr-reply-input"
                              value={replyText[post.id] || ""}
                              onChange={e => setReplyText(r => ({ ...r, [post.id]: e.target.value }))}
                              onKeyDown={e => e.key === "Enter" && addReply(post.id)}
                              placeholder="Write a supportive reply…"/>
                            <button className="vr-reply-btn"
                              disabled={replyLoading[post.id] || !(replyText[post.id] || "").trim()}
                              onClick={() => addReply(post.id)}>
                              {replyLoading[post.id]
                                ? <Loader2 size={13} className="spin"/>
                                : <Send size={13}/>}
                              Reply
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="vr-login-nudge">
                          <span>Want to reply?</span>
                          <button onClick={() => openAuth("login")}>Sign in</button>
                          <span>or</span>
                          <button onClick={() => openAuth("register")}>create an account</button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </section>

            {/* ── Safety note ──────────────────────────────────────────── */}
            <section id="safety" className="vr-safety">
              <div className="vr-safety-title"><AlertCircle size={17}/> Safety note</div>
              <p>
                This community is for emotional support and personal experiences. It is not a replacement
                for therapy, diagnosis, crisis services, or medical care. If someone is in immediate
                danger or might hurt themselves, please contact emergency services or a crisis hotline right away.
              </p>
            </section>
          </main>
        </div>
      </div>

      {/* ── Auth Modal ───────────────────────────────────────────────────── */}
      {showAuth && (
        <AuthModal
          defaultTab={authTab}
          verifiedMsg={verifiedMsg}
          onClose={() => { setShowAuth(false); setVerifiedMsg(""); }}
          onSuccess={(u) => { setUser(u); setShowAuth(false); setVerifiedMsg(""); }}
        />
      )}
    </>
  );
}
